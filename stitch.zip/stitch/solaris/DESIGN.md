# Design System Specification: The Radiant Kinetic

This document outlines the visual language and structural logic of the design system. It is engineered to transform "playful" into "sophisticated" by utilizing editorial layouts, tonal layering, and high-energy color theory. We are moving away from the "standard app" look toward a "Digital Playground"—an environment that feels open-source, community-driven, and meticulously crafted.

## 1. Creative North Star: "The Kinetic Playground"
The North Star for this system is **The Kinetic Playground**. We reject the static, boxy nature of traditional SaaS interfaces. Instead, we embrace a sense of buoyant energy. By combining hyper-rounded geometries with an editorial type scale, we create a space that feels soft to the touch but intellectually sharp. The goal is "Playful Minimalism"—where white space isn't just empty, it’s a stage for vibrant action.

## 2. Color & Surface Architecture
The palette is built on warmth and clarity. We prioritize light-filled surfaces punctuated by high-saturation "energy nodes."

### The "No-Line" Rule
**Explicit Instruction:** Traditional 1px solid borders are strictly prohibited for sectioning or containment. 
Boundaries must be defined through:
*   **Background Shifts:** Use `surface-container-low` sections against a `surface` background.
*   **Tonal Transitions:** Define areas through the interaction of light and shadow rather than mechanical lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. We use Material-style tiers to create "nested" depth:
*   **Base:** `surface` (#f6f6f6) for the overall canvas.
*   **The Well:** `surface-container-low` (#f0f1f1) for secondary content areas or sidebars.
*   **The Island:** `surface-container-lowest` (#ffffff) for primary cards or interactive modules.
*   **The Pop:** `surface-container-highest` (#dbdddd) for subtle emphasis on hover states.

### The Glass & Gradient Rule
To prevent the UI from feeling flat, utilize **Glassmorphism** for floating elements (modals, dropdowns, sticky navs). Use semi-transparent surface colors with a `backdrop-blur` of 12px–20px. 
*   **Signature Textures:** Apply subtle linear gradients (e.g., `primary` to `primary-container`) on large CTAs to provide a "liquid" feel that flat hex codes cannot replicate.

## 3. Typography: The Editorial Rounded
We utilize **Plus Jakarta Sans** for its unique blend of geometric precision and friendly curves. This is an editorial approach to rounded typography.

*   **Display (Large/Medium/Small):** Used for "Hero" moments. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) to create a bold, confident entry point.
*   **Headlines & Titles:** These drive the information architecture. `headline-md` (1.75rem) should feel rhythmic and rhythmic across the page.
*   **Body & Labels:** `body-lg` (1rem) is our workhorse. Ensure line heights are generous (1.6) to maintain the "breathable" feel of the system.

The hierarchy communicates a "friendly expert" vibe—authoritative in scale but approachable in letterform.

## 4. Elevation & Depth
We eschew traditional "drop shadows" in favor of **Tonal Layering** and **Ambient Light**.

*   **The Layering Principle:** Depth is achieved by stacking. Place a `surface-container-lowest` card on a `surface-container-low` section to create a natural, soft lift.
*   **Ambient Shadows:** For floating elements, use extra-diffused shadows. 
    *   *Shadow Formula:* `0px 20px 40px rgba(45, 47, 47, 0.06)`. 
    *   The shadow must be tinted with the `on-surface` color, never pure black.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility, use the `outline-variant` token at **15% opacity**. This creates a suggestion of a boundary without the "boxed-in" feel of neo-brutalism.

## 5. Components

### Buttons & Interaction
*   **Primary:** High-vibrancy `primary-container` (#fd933d). Use `xl` (3rem) corner radius. These should feel like "pill" buttons. 
*   **Secondary:** `secondary-container` (#ffca51) with `on-secondary-container` text. This is for supporting actions.
*   **Tertiary:** No background; use `primary` color text with a background shift to `surface-container-high` on hover.

### Cards & Lists
*   **No Dividers:** Vertical white space (using the 16px/24px/32px scale) is the only separator.
*   **Shape:** Use `lg` (2rem) or `xl` (3rem) rounding. The "squircle" look is essential to the brand personality.
*   **Nesting:** Cards should live on a slightly darker surface to "pop" forward naturally.

### Input Fields
*   **Style:** Minimalist. No bottom line. Use a `surface-container-low` background with `xl` rounding.
*   **Focus State:** A 2px "Ghost Border" using the `primary` color at 40% opacity.

### Floating Action Buttons (FABs)
*   For the community/open-source vibe, use larger-than-average FABs with the `tertiary-fixed` (#f2c026) color to act as a "sun" in the corner of the layout.

## 6. Do’s and Don’ts

### Do
*   **Do** embrace asymmetry. Offset your headers or use varied card widths to create a "zonal" editorial feel.
*   **Do** use the `primary` orange (#fb923c) as a functional accent—save it for things that move the user forward.
*   **Do** use `full` (9999px) rounding for tags, chips, and pill-style indicators.

### Don't
*   **Don't** use 100% opaque black for text. Always use `on-surface` (#2d2f2f) to keep the contrast "soft-high."
*   **Don't** use shadows on every card. Rely on background color shifts first. Shadows are for "interruptive" elements only (modals, menus).
*   **Don't** use rigid 90-degree corners anywhere. Even the smallest tooltip must have at least `sm` (0.5rem) rounding.

---
**Director's Note:** This system is not a template; it is a kit of parts for building a community. Every screen should feel like a sunny day—intentional, warm, and easy to navigate. Use the white space as your most powerful tool.