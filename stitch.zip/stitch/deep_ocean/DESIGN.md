# Design System Strategy: Deep Ocean Narrative

## 1. Overview & Creative North Star: "The Obsidian Archive"
This design system moves away from the typical "flat" open-source aesthetic toward a high-end, editorial experience. We define the North Star as **"The Obsidian Archive."** 

Like light reflecting off dark volcanic glass, this system relies on the interplay between the void (`surface`) and precision-engineered light (`primary`). We avoid generic layouts by utilizing **Intentional Asymmetry**: using large `display` typography balanced against condensed `label` metadata. This creates a rhythmic "developer-editorial" feel—where the tool feels as authoritative as a research journal but as sharp as a modern IDE. 

We break the "template" look by treating the interface not as a grid of boxes, but as a series of nested, illuminated chambers.

---

## 2. Colors & Surface Philosophy
The palette is rooted in high-contrast "Deep Navy" and "Slate" to ensure the "Professional" persona is felt immediately.

### The "No-Line" Rule
Standard 1px solid borders are strictly prohibited for sectioning content. To define boundaries, designers must use **Background Tonal Shifts**. For example, a sidebar should be `surface_container_low` while the main content area sits on `surface`. This creates a sophisticated, "borderless" flow that feels integrated and premium.

### Surface Hierarchy & Nesting
Depth is achieved through the physical logic of light.
*   **Base Layer:** `surface` (#0b1326) – The foundation.
*   **Sectioning:** `surface_container_low` (#131b2e) – Used for primary content zones.
*   **Interactive Units:** `surface_container_high` (#222a3d) – Used for cards or items that require user focus.
*   **Active/Floating:** `surface_container_highest` (#2d3449) – Reserved for modals or elevated state-changes.

### Signature Textures
While the base is dark, interactive elements should feel "energized." Apply a subtle linear gradient to main CTAs transitioning from `primary` (#8aebff) to `primary_container` (#22d3ee) at a 135-degree angle. This provides a "glow" that flat hex codes cannot replicate.

---

## 3. Typography: The Intellectual Edge
We pair the utilitarian clarity of **Inter** with the technical precision of **Space Grotesk** for labels.

*   **The Power Scale:** Use `display-lg` for empty states or landing hero sections to create a bold, "Digital Curator" presence.
*   **The Metadata Layer:** `label-md` and `label-sm` (Space Grotesk) are the "Developer's Signature." Use these for technical data, file sizes, or commit hashes. The monolinear nature of Space Grotesk adds a layer of "Open Source" authenticity.
*   **Contrast as Hierarchy:** Headlines (`headline-md`) should always be `on_surface` (High contrast), while secondary metadata should drop to `on_surface_variant` (#bbc9cd) to allow the eye to glide over less critical information.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "web 2.0" for this system. We use **Ambient Depth**.

*   **The Layering Principle:** Instead of a shadow, place a `surface_container_highest` card on a `surface_container_low` background. The subtle shift in hex value creates a "natural" lift.
*   **Ambient Shadows:** For floating elements (Modals/Popovers), use a custom shadow: `0px 20px 40px rgba(6, 14, 32, 0.6)`. The shadow is a darker version of the navy background, not black, ensuring the UI feels like it’s glowing from within.
*   **The "Ghost Border" Fallback:** If high-density data requires containment, use a 1px border with `outline_variant` at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons
*   **Primary:** Gradient of `primary` to `primary_container`. Text color: `on_primary`. Radius: `xl` (12px).
*   **Secondary:** Ghost style. No fill, `outline` border at 20% opacity. Text: `primary`.
*   **Tertiary:** Text-only, using `label-md` in `primary` for a "low-noise" interaction.

### Input Fields
Inputs must use `surface_container_low` as the fill. On focus, the border transitions to a 1px `primary` glow, and the label (`label-sm`) shifts to `primary` color. Avoid 100% white backgrounds for inputs.

### Data Cards
Forbid divider lines between card sections. Use a `1.5rem` (24px) vertical gap or a subtle color block of `surface_container_highest` for the card header. All cards must use `xl` (12px) rounding to maintain the "Modern Professional" edge.

### Archive Specific: The "Hash Chip"
A bespoke component for this system: A small, low-profile chip for commit IDs or file types. Use `surface_container_highest` with `on_surface_variant` text in `label-sm` (Space Grotesk). It should look like a piece of metadata stamped onto the UI.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use extreme vertical rhythm. Give headers more top-margin than bottom-margin to create an editorial flow.
*   **Do** use `primary` sparingly. It is a "laser pointer" to guide the user's eye to the most important action.
*   **Do** utilize `on_surface_variant` for all non-essential text to maintain the "Deep Ocean" mood.

### Don't:
*   **Don't** use pure black (#000) or pure white (#FFF). It breaks the sophisticated tonal range of the navy/cyan theme.
*   **Don't** use 1px solid borders to separate list items. Use 8px or 12px of spacing instead.
*   **Don't** use standard "Blue" icons. Use `primary` for active icons and `outline` for inactive ones.